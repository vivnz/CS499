import { useEffect, useRef, useState } from 'react'
import { saveCanvasData } from "./supabaseClient.js";
import './App.css'

function App() {
    const canvasRef = useRef(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const [color, setColor] = useState('#000000');
    // Data structure to store drawn pixels for Supabase
    const [pixels, setPixels] = useState([]);
    // Flag to track if changes exist since last save (Efficiency)
    const [isDirty, setIsDirty] = useState(false);
    const pixelSize = 10;

    // Initialize Canvas
    useEffect(() => {
        const canvas = canvasRef.current;

        const ctx = canvas.getContext('2d');

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
    }, []);


    const draw = (e) => {
        if (!isDrawing) return;

        const canvas = canvasRef.current;

        const ctx = canvas.getContext('2d');

        const rect = canvas.getBoundingClientRect();

        // Calculate coordinates relative to canvas
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // Snap grid algorithm
        const snappedX = Math.floor(x / pixelSize) * pixelSize;
        const snappedY = Math.floor(y / pixelSize) * pixelSize;

        // 1. Update Visual Canvas
        ctx.fillStyle = color;
        ctx.fillRect(snappedX, snappedY, pixelSize, pixelSize);

        // Use functional update to avoid stale state issues
        setPixels((prev) => [...prev, newPixel]);
        setIsDirty(true);
    };

    return (
        <div className="App">
            <div style={{ marginBottom: '10px' }}>
                <input
                    type="color"
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                />
            </div>

            <canvas
                ref={canvasRef}
                width={500}
                height={500}
                style={{ border: '2px solid #333', cursor: 'crosshair' }}
                onMouseDown={() => setIsDrawing(true)}
                onMouseUp={() => setIsDrawing(false)}
                onMouseMove={draw}
                onMouseLeave={() => setIsDrawing(false)}
            />
        </div>
    );
}

export default App;